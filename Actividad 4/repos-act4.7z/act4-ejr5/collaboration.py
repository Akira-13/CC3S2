print('Collaboration is key!')
