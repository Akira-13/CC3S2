print('Hello World - updated in main')
print('Hello World')
def greet():
 print('Hello from advanced feature')
 print("Fixed bug in feature")
greet()
print('Cherry pick this!')
Another change
This change is stashed
