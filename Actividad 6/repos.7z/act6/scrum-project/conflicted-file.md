Cambio en la misma linea
Cambio diferente en la misma linea
